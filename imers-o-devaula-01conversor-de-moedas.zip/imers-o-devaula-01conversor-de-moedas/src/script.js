var valorEmRealFixado = (5.50 * parseFloat(prompt("Qual o valor da facada no rim?"))).toFixed(2)

// var valorEmDolarTexto = prompt("Qual o valor da facada no rim?")
// var valorEmDolarNumero = parseFloat(valorEmDolarTexto) 
// var valorEmReal = valorEmDolarNumero * 5.50
// var valorEmRealFixado = valorEmReal.toFixed(2)

alert(valorEmRealFixado)

// Revisão
// variáveis = guardar valores que a gente deseja
// podem ser = var int - float - string
// alert
// parseInt
// parseFloat
// prompt