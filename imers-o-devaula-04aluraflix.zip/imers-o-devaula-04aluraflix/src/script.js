var filmes = ["Toy Story","Star Wars","Interestelar","Esqueceram de Mim"]

var listaFilmes = ["https://m.media-amazon.com/images/M/MV5BMDU2ZWJlMjktMTRhMy00ZTA5LWEzNDgtYmNmZTEwZTViZWJkXkEyXkFqcGdeQXVyNDQ2OTk4MzI@._V1_UX182_CR0,0,182,268_AL_.jpg", "https://m.media-amazon.com/images/M/MV5BNzVlY2MwMjktM2E4OS00Y2Y3LWE3ZjctYzhkZGM3YzA1ZWM2XkEyXkFqcGdeQXVyNzkwMjQ5NzM@._V1_UX182_CR0,0,182,268_AL_.jpg", "https://m.media-amazon.com/images/M/MV5BZjdkOTU3MDktN2IxOS00OGEyLWFmMjktY2FiMmZkNWIyODZiXkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_UX182_CR0,0,182,268_AL_.jpg"]

// var filmeEscolhido = prompt("Digite 0 para Toy Story, 1 para Star Wars e 2 para Interestelar")

// document.write("<img src=" + listaFilmes[filmeEscolhido] + ">")

for (var i = 0; i < listaFilmes.length; i++){
 document.write("<img src=" + listaFilmes[i] + ">")  
 }




// var filmes = ["Star Wars","Toy Story","Interestellar","Esqueceram de Mim","Marley e Eu"]

// var tentativas = 3   // tem que declarar a tentativa fora do while, diferente do for

// while(tentativas > 0){
  
//   tentativas = tentativas -1
// }

// for (var i = 0; i < filmes.length; i++){     // i de iteração  /  i-- = i-1  /  i++ = i + 1 
//   console.log(filmes[i])         // o que vai vir dentro dos bigodes do for é o que será executado entre a 2ª e 3ª parte do for
//}



// filmes.push("Star Wars")
// filmes.push("Toy Story")

// console.log(filmes[0])
// console.log(filmes[1])
// console.log(filmes[2])
// console.log(filmes.length)

// console.log(filmes.lenght)



