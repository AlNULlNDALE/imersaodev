var primeiroValor = parseInt(prompt('Digite o primeiro valor:'))
var segundoValor = parseInt(prompt('Digite o segundo valor:'))

var operacao = prompt("Digite 1 para fazer uma divisão, 2 para multiplicação, 3 para soma e 4 para subtração: ")

if (operacao == 1) {           // dois iguais não atribui valor à variável, apenas compara

var resultado = primeiroValor / segundoValor
document.write("<h2>" + primeiroValor + " / " + segundoValor + " = " + resultado + "</h2>") //concatenar strings  
} else if (operacao == 2){
  
  var resultado = primeiroValor * segundoValor
  document.write("<h2>" + primeiroValor + " x " + segundoValor + " = " + resultado + "</h2>") //concatenar strings 
  
} else if (operacao == 3){
  
  var resultado = primeiroValor + segundoValor
  document.write("<h2>" + primeiroValor + " + " + segundoValor + " = " + resultado + "</h2>") //concatenar strings 
  
} else if (operacao == 4){
  
  var resultado = primeiroValor - segundoValor
  document.write("<h2>" + primeiroValor + " - " + segundoValor + " = " + resultado + "</h2>") //concatenar strings 
  
}  else {
  
   alert("Opção Inválida")
  
  // document.write("<h2>Opção Inválida</h2>")    // como se trata apenas de uma string, não precisa colocar o +
} 


// Resumo da Aula:
// escrevendo na tela com o document.write
// concatenação: juntar palavras, com variáveis e etc.
// if = se
// else = senão
// else if = senão se
// NaN = pesquise no google quando o código retornar algo inesperado: Not a Number
// diferença entre o igual de atribuição (=) e o igual de comparação (==)