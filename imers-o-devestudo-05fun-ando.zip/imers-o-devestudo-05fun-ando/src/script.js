var campoFilme = document.querySelector('#URLdoFilme')  
var filme = campoFilme.value 

function adicionarFilme(){    
  validaFilme(filme)
  campoFilme.value = "" 
}    

function validaFilme(){
  var filme = campoFilme.value  // pq se eu tirar essa linha, o código entende tudo como imagem inválida?
  if(filme.endsWith('.jpg')){ 
    listaFilmesNaTela(filme) 
  } else {
    alert("Imagem Inválida")
  }
}

function listaFilmesNaTela(URLdoFilme){      //pq aqui precisa de um parâmetro? e nas outras funções não? Acho que é porque eu vou precisar exibir esse parâmetro lá no html, por isso já defini ele ali. Nas outras eu não preciso retornar a entrada da função
  var elementoFilme = "<img src=" + URLdoFilme + ">"
  document.querySelector('#listaFilmes').innerHTML = document.querySelector('#listaFilmes').innerHTML + elementoFilme 
}

