function funcao() {
 var valor = document.querySelector('#valor').value 
 valor = (parseFloat(valor - 32) / 1.8).toFixed(2)
 // document.querySelector('#resultado').innerHTML = valor + " graus celsius portiolis" 
 document.getElementById('resultado').innerHTML = valor + " graus celsius" 
}