// Document.write: não dá o poder de escolher onde na página eu vou escrever

// Programinha #1

// const button = document.querySelector("button")

// function atualiza(){
// 	document.write("oi")
// }

// button.addEventListener("click", atualiza) //chama a função ATUALIZA assim que o usuário clica no botão

// **********************************************************

// Programinha #2
// agora, ao clicar no botão ATUALIZA, quero mudar o h1

// const button = document.querySelector("button")
// const h1 = document.querySelector("h1")

// function atualiza(){
// 	h1.textContent = "Atualizado"
// }

// button.addEventListener("click", atualiza) //chama a função ATUALIZA assim que o usuário clica no botão

// **********************************************************

// Programinha #3
// agora, ao clicar no botão ATUALIZA, quero adicionar algo dentro da tag DIV que criei lá no html

// const button = document.querySelector("button")
// const h1 = document.querySelector("h1")
// const div = document.querySelector("div")

// function atualiza(){
// 	const novoH1 = "<h1>Conteúdo</h1>"
// 	h1.textContent = "Atualizado"
//   div.textContent = novoH1
// }

// button.addEventListener("click", atualiza) //chama a função ATUALIZA assim que o usuário clica no botão

// **********************************************************

// Programinha #4
// agora, vamos ao innerHTML

// const button = document.querySelector("button")
// const h1 = document.querySelector("h1")
// const div = document.querySelector("div")

// function atualiza(){
// 	const novoH1 = "<h1>Conteúdo</h1>"
// 	h1.textContent = "Atualizado"
//  div.innerHTML = div.innerHTML + novoH1   //interpreta o texto que a gente vai colocar como HTML, aí sim teremos criado uma tag. Subscreve todo o conteúdo dessa DIV, ou seja, não é adicionado um novo a cada iteração.
// }

// button.addEventListener("click", atualiza) //chama a função ATUALIZA assim que o usuário clica no botão

// **********************************************************

// Programinha #5
// innerHTML é perigoso, vamos aprender o Element.insertAdjacentHTML()

const button = document.querySelector("button")
const h1 = document.querySelector("h1")
const div = document.querySelector("div")

function atualiza(){
	const novoH1 = "<h1>Conteúdo</h1>"
	h1.textContent = "Atualizado"
  div.insertAdjacentHTML("beforeend",novoH1)
}

button.addEventListener("click", atualiza) //chama a função ATUALIZA assim que o usuário clica no botão