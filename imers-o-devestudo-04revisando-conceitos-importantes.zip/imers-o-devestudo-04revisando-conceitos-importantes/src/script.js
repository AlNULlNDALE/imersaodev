// var x = 0
// var i = 0

// while(i<3){
// 	x=x+i
// 	i++
//	console.log("i=" + i)
//	console.log("x=" + x)
//}


// for (i=0;i<3;i++){
//	x = x + i
//	console.log("i=" + i)
//	console.log("x=" + x)
//}

// vendo o esqueleto do for

// var i=0;

// for (;;){
//  if(i>3)break 
//	console.log(i)
//	i++
//}

var frutas = ["maçã","banana"]

frutas.forEach(function (item,indice,array){
	console.log(item,indice)
})