function adicionarFilme(){    
  var campoFilme = document.querySelector('#filme')  
  var filme = campoFilme.value 
  filme = filme.split('https://youtu.be/')
  console.log(filme)
  //https://youtu.be/cjuqlP4hQXE
  filme = 'https://www.youtube.com/embed/' + filme[1]
  console.log(filme)
  listarFilmesNaTela(filme)
}    

function listarFilmesNaTela(filme){ 
  var listaFilmes = document.querySelector('#listaFilmes')  
  var elementoFilme = "<iframe src=" + filme + ">"
  listaFilmes.innerHTML = listaFilmes.innerHTML + elementoFilme 
}








