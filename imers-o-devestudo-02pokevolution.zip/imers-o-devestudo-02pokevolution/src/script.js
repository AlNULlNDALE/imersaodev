var pokemon = prompt('Escreva o nome do pokemon:')

if (pokemon == "pikachu") {   
  
document.write("<h2>Raichu</h2>") 
  
} else if (pokemon == "bulbasaur"){
  
  document.write("<h2>Ivysaur</h2>")  
  
} else if (pokemon == "ivysaur"){
  
  document.write("<h2>Venusaur</h2>")  
  
} else if (pokemon == "charmander"){
  
  document.write("<h2>Charmeleon</h2>")  
  
} else if (pokemon == "charmeleon"){
  
  document.write("<h2>Charizard</h2>")  
  
} else if (pokemon == "squirtle"){
  
  document.write("<h2>Wartortle</h2>")  
  
} else if (pokemon == "wartortle"){
  
  document.write("<h2>Blastoise</h2>")  
  
} else if (pokemon == "caterpie"){
  
  document.write("<h2>Metapod</h2>")  
  
} else {
  
   alert("Desculpe, não temos esse pokemon catalogado ainda!")
  
  // document.write("<h2>Opção Inválida</h2>")    // como se trata apenas de uma string, não precisa colocar o +
} 


// Resumo da Aula:
// escrevendo na tela com o document.write
// concatenação: juntar palavras, com variáveis e etc.
// if = se
// else = senão
// else if = senão se
// NaN = pesquise no google quando o código retornar algo inesperado: Not a Number
// diferença entre o igual de atribuição (=) e o igual de comparação (==)