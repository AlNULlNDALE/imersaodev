// console.log("iniciou")        //aqui vai ser executado sempre

function adicionarFilme(){    //a função só será rodada quando alguém chamá-la (o usuário, por exemplo)
  var campoFilme = document.querySelector('#filme') //pegando um elemento lá do html - a caixinha de texto branca para o usuário digitar 
  var filme = campoFilme.value //serve para extrair o endereço de imagem que o usuário digitou - é uma variável interna - não é mostrada ao usuário
//  console.log(campoFilme)
//  console.log(filme)
  if(filme.endsWith('.jpg')){ //queremos verificar se esse conteúdo termina com jpg
    listarFilmesNaTela(filme) //chamando a função abaixo que faz exibir o pôster na tela
  } else {
    alert("Imagem Inválida")
  }
  campoFilme.value = "" //tem que ser o campoFilme, e não o filme, pois o campoFilme é o que tá "visível" para o usuário; o filme é apenas uma variável interna com o endereço da imagem
}    

function listarFilmesNaTela(umFilme){ //o que ta dentro do parêntese é o parâmetro; a função espera um filme
  var listaFilmes = document.querySelector('#listaFilmes') //pegando um elemento lá do html - a parte da página debaixo do botão "Adicionar Filme" 
  var elementoFilme = "<img src=" + umFilme + ">" //criando a variável que mostrará o filme embaixo do botão "Adicionar Filme"
  listaFilmes.innerHTML = listaFilmes.innerHTML + elementoFilme //chamando a variável pra ser exibida
}

// console.log("terminou")      //aqui tbm vai ser executado sempre
