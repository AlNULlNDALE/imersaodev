var paulo = {      //objeto é sempre com bigodes
  nome: "Paulo",
  vitorias: 2,
  empates: 5,
  derrotas: 1,
  pontos: 0
}

var rafa = {
  nome: "Rafa",
  vitorias: 3,     //declarando o valor inicial de cada variável dentro do objeto
  empates: 5,
  derrotas: 2,
  pontos:0
}

rafa.pontos = calculaPontos(rafa) //chamando a função
paulo.pontos = calculaPontos(paulo)
// console.log(paulo.pontos)   //11
// console.log(rafa.pontos)    //14

function calculaPontos(jogador){  //definindo a função
  var pontos = (jogador.vitorias * 3) + jogador.empates
  return(pontos)  //aqui precisamos atribuir esse valor à alguma variável dentro do nosso programinha, se não a função só roda e fica por isso mesmo. Já quero somar esse valor na parte 'pontos' dentro do objeto do jogador correspondente. Como eu faço isso? Colocando rafa.pontos = chama a função.
}

// agora vamos passar esses valores do console para o html em si, para o usuário ver

var jogadores = [rafa, paulo]

exibirJogadoresNaTela(jogadores)

function exibirJogadoresNaTela(jogadores){
  var html = ""
  for(var i=0;i<jogadores.length; i++){
    html += "<tr><td>" + jogadores[i].nome + "</td>"
    html += "<td>" + jogadores[i].vitorias + "</td>"
    html += "<td>" + jogadores[i].empates + "</td>"
    html += "<td>" + jogadores[i].derrotas + "</td>"
    html += "<td>" + jogadores[i].pontos + "</td>"
    html += "<td><button onClick='adicionarVitoria(" + i + ")'>Vitória</button></td>"
    html += "<td><button onClick='adicionarEmpate(" + i + ")'>Empate</button></td>"
    html += "<td><button onClick='adicionarDerrota(" + i + ")'>Derrota</button></td></tr>"
  }
  var tabelaJogadores = document.getElementById("tabelaJogadores")
  tabelaJogadores.innerHTML = html
}

function adicionarVitoria(i){
  var jogador = jogadores[i]
  jogador.vitorias++            //clicou na vitória, soma 1 na vitória
  jogador.pontos = calculaPontos(jogador)
  exibirJogadoresNaTela(jogadores)
  // console.log("Clicou no botão vitoria")
}

function adicionarEmpate(i){
  var jogador = jogadores[i]
  jogador.empates++            //clicou na vitória, soma 1 na vitória
  jogador.pontos = calculaPontos(jogador)
  exibirJogadoresNaTela(jogadores)
  // console.log("Clicou no botão empate")
}

function adicionarDerrota(i){
  var jogador = jogadores[i]
  jogador.derrotas++            //clicou na vitória, soma 1 na vitória
  exibirJogadoresNaTela(jogadores)
  // console.log("Clicou no botão derrota")
}

