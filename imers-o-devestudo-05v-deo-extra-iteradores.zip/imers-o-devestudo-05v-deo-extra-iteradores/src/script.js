// que dados podemos iterar? 1) array, 2) strings e 3) objeto, por exemplo
// que tipo de iteração queremos fazer? 1) podemos querer fazer um loop enquanto uma condição não é cumprida; 2) executar o mesmo comando pra vários elementos de uma lista, encontrar uma informação específica numa lista
// o que essa iteração retorna? retorna algum dado, retorna nada, retorna quantas vezes iterou, etc.
// CUIDADO COM O LOOP INFINITO

//while

// var letraCerta = prompt('Digite a letra A')
// while (letraCerta != "A"){
// 	letraCerta = prompt('Por favor, digite a letra A')
// }

var total = 0

while(total<5){
	console.log(total)
	total++
}

