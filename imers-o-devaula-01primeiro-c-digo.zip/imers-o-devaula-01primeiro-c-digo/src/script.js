// Linguagem de programação

var nome = "Daniela"
var idade = 34

var idadeUsuario = parseInt(prompt("Quantos anos você vai fazer em 2021?"))

var anoNascimento = 2021 - idadeUsuario 

alert("Você nasceu em " + anoNascimento)