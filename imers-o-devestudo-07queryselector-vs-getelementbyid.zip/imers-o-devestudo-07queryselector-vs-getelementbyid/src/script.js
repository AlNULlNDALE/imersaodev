// Programinha #1

// const textoNaTela = document.getElementById("texto0") //pega o elemento pelo Id
// textoNaTela.textContent = "novo texto na tela"
// console.log(textoNaTela)

//******************************************

// Programinha #2

// const p = document.getElementsByTagName("p") //pega todos os ps do html: ele retornará uma lista de elementos

// console.log(p[0])
// console.log(p[1])
// console.log(p[2])
// console.log(p[3])

//******************************************

// Programinha #3

// const p = document.getElementsByClassName("texto")
// console.log(p[0])

//******************************************

// Programinha #4

// const p = document.querySelector("#texto0") //pega só o primeiro p, no caso de todos ps iguais.
// console.log(p)

//******************************************

// Programinha #5

// const p = document.querySelectorAll("p") //tbm devolve uma lista; se quiser especificar, p[0], p[1], p[2], p[3]
// console.log(p)

//******************************************

// Programinha #6

const p = document.querySelectorAll(".texto") //ele vai pegar pelas classes, e não pelo Id, já que não se pode ter Ids iguais numa mesma página.
console.log(p[1])

// Resumo: querySelector é muito mais usado hoje em dia.